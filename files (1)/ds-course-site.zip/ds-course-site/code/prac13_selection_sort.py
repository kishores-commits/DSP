"""
Practical 13 — Selection Sort
Implement selection sort by repeatedly selecting the minimum remaining element.
"""


def selection_sort(arr):
    """Sort `arr` in place and return it."""
    # TODO
    pass


if __name__ == "__main__":
    data = [9, 4, 7, 1, 3, 8, 2]
    print(selection_sort(data))
