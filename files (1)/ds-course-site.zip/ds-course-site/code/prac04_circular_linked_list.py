"""
Practical 04 — Circular Linked List
Demonstrate append, delete, and iteration.
"""


class CNode:
    def __init__(self, data):
        self.data = data
        self.next = None


class CircularLinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        # TODO: add a node and keep the list circular (last node -> head)
        pass

    def delete(self, data):
        # TODO: remove the first node containing `data`
        pass

    def iterate(self):
        # TODO: return a list of all data values, traversing once around the circle
        pass


if __name__ == "__main__":
    cll = CircularLinkedList()
    cll.append("a")
    cll.append("b")
    cll.append("c")
    print(cll.iterate())
