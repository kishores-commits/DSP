"""
Practical 06 — Bracket Matching
Use a stack to check whether brackets in an expression are balanced.
"""


def is_balanced(expression):
    """Return True if all (), [], {} in `expression` are correctly matched."""
    # TODO: push opening brackets, pop and compare on closing brackets
    pass


if __name__ == "__main__":
    tests = ["{[()]}", "([)]", "((()))", "(()"]
    for t in tests:
        print(t, "->", is_balanced(t))
