"""
Practical 11 — Quick Sort
Implement quick sort, including partitioning and pivot selection.
"""


def quick_sort(arr):
    """Return a new list containing the elements of `arr` in sorted order."""
    # TODO: choose a pivot, partition, recurse on each side
    pass


if __name__ == "__main__":
    data = [9, 4, 7, 1, 3, 8, 2]
    print(quick_sort(data))
