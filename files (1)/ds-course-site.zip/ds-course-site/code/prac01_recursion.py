"""
Practical 01 — Recursion
Demonstrate recursion in Python (e.g. factorial and/or Fibonacci).
"""


def factorial(n):
    """Return n! using recursion."""
    # TODO: write the recursive logic
    pass


def fibonacci(n):
    """Return the n-th Fibonacci number using recursion."""
    # TODO: write the recursive logic
    pass


if __name__ == "__main__":
    print("factorial(5) =", factorial(5))
    print("fibonacci(7) =", fibonacci(7))
