"""
Practical 02 — Singly Linked List
Implement append, delete, search, and size operations.
"""


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        # TODO: add a new node to the end of the list
        pass

    def delete(self, data):
        # TODO: remove the first node containing `data`
        pass

    def search(self, data):
        # TODO: return True if `data` is found, else False
        pass

    def size(self):
        # TODO: return the number of nodes
        pass

    def __str__(self):
        # TODO: return a readable string of the list, e.g. "1 -> 2 -> 3"
        pass


if __name__ == "__main__":
    ll = SinglyLinkedList()
    ll.append(10)
    ll.append(20)
    ll.append(30)
    print(ll)
    print("size:", ll.size())
    print("search 20:", ll.search(20))
    ll.delete(20)
    print(ll)
