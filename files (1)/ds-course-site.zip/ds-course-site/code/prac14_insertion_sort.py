"""
Practical 14 — Insertion Sort
Implement insertion sort by growing a sorted prefix of the list.
"""


def insertion_sort(arr):
    """Sort `arr` in place and return it."""
    # TODO
    pass


if __name__ == "__main__":
    data = [9, 4, 7, 1, 3, 8, 2]
    print(insertion_sort(data))
