"""
Practical 10 — Merge Sort
Implement merge sort using the divide-and-conquer paradigm.
"""


def merge_sort(arr):
    """Return a new list containing the elements of `arr` in sorted order."""
    # TODO: split, recursively sort each half, then merge
    pass


if __name__ == "__main__":
    data = [9, 4, 7, 1, 3, 8, 2]
    print(merge_sort(data))
