"""
Practical 12 — Bubble Sort
Implement bubble sort with adjacent-pair comparisons and swaps.
"""


def bubble_sort(arr):
    """Sort `arr` in place and return it."""
    # TODO
    pass


if __name__ == "__main__":
    data = [9, 4, 7, 1, 3, 8, 2]
    print(bubble_sort(data))
