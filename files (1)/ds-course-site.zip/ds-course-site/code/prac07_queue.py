"""
Practical 07 — Queue
Implement a list-based queue with enqueue and dequeue operations.
"""


class Queue:
    def __init__(self):
        self.items = []

    def enqueue(self, item):
        # TODO: add an item to the back of the queue
        pass

    def dequeue(self):
        # TODO: remove and return the item at the front of the queue
        pass

    def is_empty(self):
        return len(self.items) == 0


if __name__ == "__main__":
    q = Queue()
    q.enqueue("a")
    q.enqueue("b")
    q.enqueue("c")
    print(q.dequeue())
    print(q.dequeue())
