"""
Practical 08 — Expression Evaluation
Evaluate a postfix expression using a stack.
"""


def evaluate_postfix(expression):
    """
    Evaluate a postfix expression given as a space-separated string,
    e.g. "5 3 + 2 *" -> 16
    """
    # TODO: push operands; on an operator, pop two operands, apply it, push result
    pass


if __name__ == "__main__":
    print(evaluate_postfix("5 3 + 2 *"))   # expected: 16
    print(evaluate_postfix("6 2 /"))       # expected: 3
