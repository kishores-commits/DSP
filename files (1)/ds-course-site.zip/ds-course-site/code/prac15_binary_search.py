"""
Practical 15 — Binary Search
Implement binary search on a sorted list.
"""


def binary_search(arr, target):
    """Return the index of `target` in sorted list `arr`, or -1 if not found."""
    # TODO
    pass


if __name__ == "__main__":
    data = [1, 3, 4, 7, 8, 9, 12, 15]
    print(binary_search(data, 9))   # expected: 5
    print(binary_search(data, 5))   # expected: -1
