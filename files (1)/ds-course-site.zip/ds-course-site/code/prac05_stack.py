"""
Practical 05 — Stack
Implement push, pop, and peek operations.
"""


class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        # TODO
        pass

    def pop(self):
        # TODO: remove and return the top item
        pass

    def peek(self):
        # TODO: return the top item without removing it
        pass

    def is_empty(self):
        return len(self.items) == 0


if __name__ == "__main__":
    s = Stack()
    s.push(1)
    s.push(2)
    s.push(3)
    print("peek:", s.peek())
    print("pop:", s.pop())
    print("peek:", s.peek())
