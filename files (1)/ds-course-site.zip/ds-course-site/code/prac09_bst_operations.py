"""
Practical 09 — Binary Search Tree
Implement insertion, deletion, search, and traversal (inorder, preorder, postorder).
"""


class TreeNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert(self, data):
        # TODO
        pass

    def delete(self, data):
        # TODO
        pass

    def search(self, data):
        # TODO: return True if `data` exists in the tree
        pass

    def inorder(self):
        # TODO: return a list of values, left -> root -> right
        pass

    def preorder(self):
        # TODO: return a list of values, root -> left -> right
        pass

    def postorder(self):
        # TODO: return a list of values, left -> right -> root
        pass


if __name__ == "__main__":
    bst = BinarySearchTree()
    for value in [50, 30, 70, 20, 40, 60, 80]:
        bst.insert(value)
    print("inorder:", bst.inorder())
    print("preorder:", bst.preorder())
    print("postorder:", bst.postorder())
