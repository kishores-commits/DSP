"""
Practical 03 — Doubly Linked List
Implement append, delete, and search operations.
"""


class DNode:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None


class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def append(self, data):
        # TODO: add a new node at the tail, linking prev/next correctly
        pass

    def delete(self, data):
        # TODO: remove the first node containing `data`
        pass

    def search(self, data):
        # TODO: return True if `data` is found, else False
        pass

    def __str__(self):
        # TODO: return a readable string, e.g. "1 <-> 2 <-> 3"
        pass


if __name__ == "__main__":
    dll = DoublyLinkedList()
    dll.append(1)
    dll.append(2)
    dll.append(3)
    print(dll)
